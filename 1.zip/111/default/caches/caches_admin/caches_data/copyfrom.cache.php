<?php
return array (
  1 => 
  array (
    'id' => '1',
    'siteid' => '1',
    'sitename' => '辽宁股权交易中心',
    'siteurl' => 'http://www.52cjw.com',
    'thumb' => '',
    'listorder' => '0',
  ),
  15 => 
  array (
    'id' => '15',
    'siteid' => '1',
    'sitename' => '重庆股份转让中心',
    'siteurl' => 'http://www.52cjw.com',
    'thumb' => '',
    'listorder' => '0',
  ),
  16 => 
  array (
    'id' => '16',
    'siteid' => '1',
    'sitename' => '上海股权托管交易中心',
    'siteurl' => 'http://www.52cjw.com',
    'thumb' => '',
    'listorder' => '0',
  ),
  17 => 
  array (
    'id' => '17',
    'siteid' => '1',
    'sitename' => '浙江股权交易中心',
    'siteurl' => 'http://www.52cjw.com',
    'thumb' => '',
    'listorder' => '0',
  ),
  18 => 
  array (
    'id' => '18',
    'siteid' => '1',
    'sitename' => '江西省股权交易所',
    'siteurl' => 'http://www.52cjw.com',
    'thumb' => '',
    'listorder' => '0',
  ),
  19 => 
  array (
    'id' => '19',
    'siteid' => '1',
    'sitename' => '天津股权交易所',
    'siteurl' => 'http://www.52cjw.com',
    'thumb' => '',
    'listorder' => '0',
  ),
  20 => 
  array (
    'id' => '20',
    'siteid' => '1',
    'sitename' => '深圳前海股权交易中心',
    'siteurl' => 'http://www.52cjw.com',
    'thumb' => '',
    'listorder' => '0',
  ),
  21 => 
  array (
    'id' => '21',
    'siteid' => '1',
    'sitename' => '广西北部湾股权托管交易所',
    'siteurl' => 'http://www.52cjw.com',
    'thumb' => '',
    'listorder' => '0',
  ),
  22 => 
  array (
    'id' => '22',
    'siteid' => '1',
    'sitename' => '广州股权交易中心',
    'siteurl' => 'http://www.52cjw.com',
    'thumb' => '',
    'listorder' => '0',
  ),
  23 => 
  array (
    'id' => '23',
    'siteid' => '1',
    'sitename' => '广东金融高新区股权交易中心',
    'siteurl' => 'http://www.52cjw.com',
    'thumb' => '',
    'listorder' => '0',
  ),
  24 => 
  array (
    'id' => '24',
    'siteid' => '1',
    'sitename' => '福建海峡股权交易中心',
    'siteurl' => 'http://www.52cjw.com',
    'thumb' => '',
    'listorder' => '0',
  ),
  14 => 
  array (
    'id' => '14',
    'siteid' => '1',
    'sitename' => '湖南股权交易所',
    'siteurl' => 'http://www.52cjw.com',
    'thumb' => '',
    'listorder' => '0',
  ),
  13 => 
  array (
    'id' => '13',
    'siteid' => '1',
    'sitename' => '武汉股权托管交易吣',
    'siteurl' => 'http://www.52cjw.com',
    'thumb' => '',
    'listorder' => '0',
  ),
  12 => 
  array (
    'id' => '12',
    'siteid' => '1',
    'sitename' => '安徽省股权交易所',
    'siteurl' => 'http://www.52cjw.com',
    'thumb' => '',
    'listorder' => '0',
  ),
  2 => 
  array (
    'id' => '2',
    'siteid' => '1',
    'sitename' => '吉林股权交易所',
    'siteurl' => 'http://www.52cjw.com',
    'thumb' => '',
    'listorder' => '0',
  ),
  3 => 
  array (
    'id' => '3',
    'siteid' => '1',
    'sitename' => '内蒙古股权交易中心',
    'siteurl' => 'http://www.52cjw.com',
    'thumb' => '',
    'listorder' => '0',
  ),
  4 => 
  array (
    'id' => '4',
    'siteid' => '1',
    'sitename' => '甘肃股权交易中心',
    'siteurl' => 'http://www.52cjw.com',
    'thumb' => '',
    'listorder' => '0',
  ),
  5 => 
  array (
    'id' => '5',
    'siteid' => '1',
    'sitename' => '新疆股权交易中心',
    'siteurl' => 'http://www.52cjw.com',
    'thumb' => '',
    'listorder' => '0',
  ),
  6 => 
  array (
    'id' => '6',
    'siteid' => '1',
    'sitename' => '北京股权交易中心',
    'siteurl' => 'http://www.52cjw.com',
    'thumb' => '',
    'listorder' => '0',
  ),
  7 => 
  array (
    'id' => '7',
    'siteid' => '1',
    'sitename' => '青海股权交易中心',
    'siteurl' => 'http://www.52cjw.com',
    'thumb' => '',
    'listorder' => '0',
  ),
  8 => 
  array (
    'id' => '8',
    'siteid' => '1',
    'sitename' => '陕西股权交易中心',
    'siteurl' => 'http://www.52cjw.com',
    'thumb' => '',
    'listorder' => '0',
  ),
  9 => 
  array (
    'id' => '9',
    'siteid' => '1',
    'sitename' => '山西股权交易中心',
    'siteurl' => 'http://www.52cjw.com',
    'thumb' => '',
    'listorder' => '0',
  ),
  10 => 
  array (
    'id' => '10',
    'siteid' => '1',
    'sitename' => '齐鲁股权托管交易中心',
    'siteurl' => 'http://www.52cjw.com',
    'thumb' => '',
    'listorder' => '0',
  ),
  11 => 
  array (
    'id' => '11',
    'siteid' => '1',
    'sitename' => '江苏股权交易中心',
    'siteurl' => 'http://www.52cjw.com',
    'thumb' => '',
    'listorder' => '0',
  ),
  25 => 
  array (
    'id' => '25',
    'siteid' => '1',
    'sitename' => '厦门两岸股权交易中心',
    'siteurl' => 'http://www.52cjw.com',
    'thumb' => '',
    'listorder' => '0',
  ),
);
?>