<?php
return array (
  1 => 
  array (
    'typeid' => '1',
    'name' => '新闻动态',
    'sort' => '1',
  ),
  13 => 
  array (
    'typeid' => '54',
    'name' => '合作企业',
    'sort' => '2',
  ),
  12 => 
  array (
    'typeid' => '53',
    'name' => '挂牌企业',
    'sort' => '3',
  ),
);
?>