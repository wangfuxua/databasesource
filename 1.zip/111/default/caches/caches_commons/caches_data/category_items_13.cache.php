<?php
return array (
  35 => '9',
  37 => '25',
);
?>