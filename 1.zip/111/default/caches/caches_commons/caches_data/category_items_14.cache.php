<?php
return array (
  36 => '4',
);
?>