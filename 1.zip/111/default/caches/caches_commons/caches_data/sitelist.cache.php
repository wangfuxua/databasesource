<?php
return array (
  1 => 
  array (
    'siteid' => '1',
    'name' => '四板财经网',
    'dirname' => '',
    'domain' => 'http://123.57.138.213/',
    'site_title' => '四板财经网',
    'keywords' => '四板财经网',
    'description' => '四板财经网',
    'release_point' => '',
    'default_style' => 'default',
    'template' => 'default',
    'setting' => 'array (
  \'upload_maxsize\' => \'2048\',
  \'upload_allowext\' => \'jpg|jpeg|gif|bmp|png|doc|docx|xls|xlsx|ppt|pptx|pdf|txt|rar|zip|swf\',
  \'watermark_enable\' => \'0\',
  \'watermark_minwidth\' => \'300\',
  \'watermark_minheight\' => \'300\',
  \'watermark_img\' => \'statics/images/water//mark.png\',
  \'watermark_pct\' => \'85\',
  \'watermark_quality\' => \'80\',
  \'watermark_pos\' => \'9\',
)',
    'uuid' => '15b95844-d10f-11e4-b115-00163e000a18',
    'url' => 'http://123.57.138.213/',
  ),
);
?>