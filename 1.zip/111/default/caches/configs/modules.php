<?php
return array (
  'member' => '会员',
  'special' => '专题',
  'content' => '内容模块',
  'announce' => '公告',
  'comment' => '评论',
  'link' => '友情链接',
  'vote' => '投票',
  'wap' => '手机门户',
);
?>