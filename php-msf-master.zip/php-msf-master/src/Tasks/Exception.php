<?php
/**
 * 同步任务异常
 *
 * @author camera360_server@camera360.com
 * @copyright Chengdu pinguo Technology Co.,Ltd.
 */

namespace PG\MSF\Tasks;

use PG\MSF\Base\Exception as BaseException;

/**
 * Class Exception
 * @package PG\MSF\Tasks
 */
class Exception extends BaseException
{
}
