<?php
/**
 * 路由异常
 *
 * @author camera360_server@camera360.com
 * @copyright Chengdu pinguo Technology Co.,Ltd.
 */

namespace PG\MSF\Route;

use PG\MSF\Base\Exception as BaseException;

/**
 * Class Exception
 * @package PG\MSF\Route
 */
class Exception extends BaseException
{
}
