<?php
/**
 * Exception
 *
 * @author camera360_server@camera360.com
 * @copyright Chengdu pinguo Technology Co.,Ltd.
 */

namespace PG\MSF\Proxy;

use PG\MSF\Base\Exception as BaseException;

/**
 * Class Exception
 * @package PG\MSF\Proxy
 */
class Exception extends BaseException
{
}
