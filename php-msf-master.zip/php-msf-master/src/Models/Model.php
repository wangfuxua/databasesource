<?php
/**
 * Model基类
 *
 * @author camera360_server@camera360.com
 * @copyright Chengdu pinguo Technology Co.,Ltd.
 */

namespace PG\MSF\Models;

use PG\MSF\Base\Core;

/**
 * Class Model
 * @package PG\MSF\Models
 */
class Model extends Core
{
}
