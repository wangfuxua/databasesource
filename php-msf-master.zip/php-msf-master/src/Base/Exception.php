<?php
/**
 * 框架异常基类
 *
 * @author camera360_server@camera360.com
 * @copyright Chengdu pinguo Technology Co.,Ltd.
 */

namespace PG\MSF\Base;

/**
 * Class Exception
 * @package PG\MSF\Base
 */
class Exception extends \Exception
{
}
