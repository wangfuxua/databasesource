<?php
/**
 * 连接池异常
 *
 * @author camera360_server@camera360.com
 * @copyright Chengdu pinguo Technology Co.,Ltd.
 */

namespace PG\MSF\Pools;

use PG\MSF\Base\Exception as BaseException;

/**
 * Class Exception
 * @package PG\MSF\Pools
 */
class Exception extends BaseException
{
}
