<?php

	$DBHOST = "localhost";

	$DBUSER = "root";
	$DBPASSWORD = "dddddd";

	$DBNAME = "webchat";

	$DBTAG = "";

	?>