// JavaScript Document
function del_confirm(){
	if(confirm("是否确认？")){
		return true;
	}else{
		return false;
	}
}